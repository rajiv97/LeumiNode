const express = require('express');
const router = express.Router();

router.get('/details', (req, res) => {
   
   res.send("done");

});



router.post("/update", (req, res) => {
    
   
   var address = req.body.address;


       var myquery= { address: "vrindavan" };
       var newvalues = { $set: { address: address } };
       const collection = db.collection('user');
       collection.updateOne(myquery,newvalues, function (err, result) {
           if (err)
               res.send("cannot update the data. Please try again later!!!!!!!!!!!!");
           else
               res.send({ msg: "data is updated in to the collection" });
           
       }); 
   
   
});


router.delete("/delete", (req, res) => {
    
   
   var address = req.body.address;


       var myquery= { address: address };
       
       const collection = db.collection('user');
       collection.remove(myquery, function (err, result) {
           if (err)
               res.send("cannot delete the data. Please try again later!!!!!!!!!!!!");
           else
               res.send({ msg: "data is deleted from the collection" });
           
       }); 
   
   
});


module.exports = router;