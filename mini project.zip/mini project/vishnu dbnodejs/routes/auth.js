const express = require('express');

const router = express.Router();
var jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');

var hashpass = '';


router.post("/register", (req, res) => {
    const saltRound = 10;
    var f_name = req.body.f_name;
    var l_name = req.body.l_name;
    var email = req.body.email;
    var phone = req.body.phone;
    var address = req.body.address;
    var pass = req.body.pass;

    bcrypt.hash(pass, saltRound, function (err, hash) {
       var hashpass = hash;
        console.log("decrypted password: "+hash);
        var obj =
        {
            First_name: f_name,
            last_name: l_name,
            Email: email,
            Phone: phone,
            address: address,
            password: hashpass
        }

        
        const collection = db.collection('user');
        collection.insertOne(obj, function (err, result) {
            if (err)
                res.send("cannot insert the data. Please try again later!!!!!!!!!!!!");
            else
                res.send({ msg: "data inserted in to the collection" });
            
        }); 

    });
    
    
});



router.post("/login", (req, res) => {
    var email = req.body.email;
    var pass = req.body.pass;
    const collection = db.collection('user');
    collection.findOne({ Email: email }, function (err, result) {
        if (result) {
            console.log("Email got detected");
            console.log(result);
            var hash = result.password;
           console.log(hash);
            bcrypt.compare(pass, hash, function(err, result) {
                // result == true
                if (result) 

{
                    console.log("password verified");
                    var token = jwt.sign({ Email: email, password: hash }, "secret-token");
                    res.send({ "one time token: ": token });
                    res.send({"status":"verifiyed"});
                }
                else {
                    console.log("password does not match:: ");
                    res.send("password doesn't match");
                }
            });
            

            }

        
            
             
                
    
            else
        res.send("email not found");
    });
    
})
  

module.exports = router;