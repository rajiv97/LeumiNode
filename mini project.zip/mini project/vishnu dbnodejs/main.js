const express = require('express');
const bodyParser = require('body-parser');
const mongo = require('mongodb').MongoClient;
var jwt = require('jsonwebtoken');
const authRouter = require("./routes/auth");
const userRouter = require("./routes/user");
const app = express();
const PORT = 9090;

app.use(bodyParser.json());


const url = "mongodb://localhost:27017";
const dbName = 'myproject';


mongo.connect(url, (err, client) => {
    if (err) {
        console.log(err);
        process.exit(0);
    }
    db = client.db(dbName);
    console.log('database connected!');

});






app.use('/auth', authRouter);//auth redirect

//middleware for verifiy jwt token

app.use(function (req, res, next) {
    var token = req.headers.token;
    jwt.verify(token, "secret-token", function (err, decoded) {
        if (err)
            res.send("INVALID TOKEN");
        else {
            console.log(".........token verified");
        next();
        }
    });
});

app.use('/user', userRouter);//auth redirect

app.listen(PORT, function () { console.log(`server listing on ${PORT}`) });