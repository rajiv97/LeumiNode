const express = require('express');
const router = express.Router();
const { defaultLogger,errorLogger } = require('../lib/logging');
var verifyToken = require('../lib/util');
/**
 * Read configuration values like screen display timeout or redirect page timeout from config file
 * and send these values as response to client.
 */
router.get('/fetchParams', (req, res, next) => {
    var userid = req.headers.userid, reqid = req.headers.requestid;
    defaultLogger.info("["+userid+"]-["+reqid+"]-Entering into Config: /fetchParams")
    const { SCREEN_DISPLAY_TIMEOUT, REDIRECT_PAGE_DISPLAY_TIMEOUT, USE_CONSENT_CALLBACK, ESB_TIMEOUT_PERIOD , TOKEN_TIMEOUT_PERIOD , BL_SORT_CODE} = require('../config/config');
    let frontEndTimeout = ESB_TIMEOUT_PERIOD;
    if(TOKEN_TIMEOUT_PERIOD > ESB_TIMEOUT_PERIOD){
        frontEndTimeout = TOKEN_TIMEOUT_PERIOD;
    }
    try {
        res.send({
            screenDisplayTimeout: SCREEN_DISPLAY_TIMEOUT,
            redirectPageDisplayTime: REDIRECT_PAGE_DISPLAY_TIMEOUT,
            useConsentCallback: USE_CONSENT_CALLBACK,
            frontEndTimeout: frontEndTimeout + 1000,
            blSortCode : BL_SORT_CODE

        })
        defaultLogger.info("["+userid+"]-["+reqid+"]-Exiting from Config: /fetchParams");
    }
    catch{
        errorLogger.info("["+userid+"]-["+reqid+"]-Error occured in router (/fetchParams):");
        errorLogger.error("["+userid+"]-["+reqid+"]-Unable to fetch properties.");
        res.status(500).send("["+userid+"]-["+reqid+"]-Unable to fetch properties.");
    }
})

/**
 * This route will log any error occured at client-side via a post call before throwing out user.
 */
router.post('/postError' , (req, res) => {
    var userid = req.headers.userid, reqid = req.headers.requestid;
    const body = req.body;
    try {
        errorLogger.error("["+userid+"]-["+reqid+"]-"+body.message);
        defaultLogger.info("["+userid+"]-["+reqid+"]-Exiting from Config: /postError");
        res.status(200).send({"message":"Error logged successfully"});
    }
    catch{
        errorLogger.error("["+userid+"]-["+reqid+"]-Failed to log error in Config: /postError");
        res.status(500).send("Unable to log error.");
    }
    
})

module.exports = router;
