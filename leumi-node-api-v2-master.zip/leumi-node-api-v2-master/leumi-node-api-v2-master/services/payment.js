const axiosClient = require('../lib/axios');
const https = require('https');
const { ESB_BASE_URL, ESB_TIMEOUT_PERIOD } = require('../config/config');
const CHECK_CBPII = ESB_BASE_URL+"/consent/cbpiiCheck/";
const SAVE_ACCOUNT = ESB_BASE_URL+"/consent/saveAuthorisedPayment/";
const { defaultLogger, errorLogger} = require('../lib/logging');


/**
 * This is Payment Service, it will manage the payment activity by User.
 */
class PaymentService {

    /**
     * cbpiiCheck - service is responsible for cross-checking if the account selected is one of the user's
     * corporate bank account to which user gave consent for confirmation of funds.
     * 
     * @param {*} authId - authId gets generated on successfull authentication (required).
     * @param {*} bankAccountId - recieved from consentRequest service call (optional). 
     * @param {*} tokenUserId - It gets generated on succesfull authentication (optional). 
     * @param {*} tppName - recieved from consentRequest service call (optional).
     */
    async cbpiiCheck(authId,bankAccountId,tokenUserId,tppName,params){
        defaultLogger.info("["+params.userid+"]-["+params.requestid+"]-Entering into cbpiiCheck())");
        var checkCbpiiUrl = CHECK_CBPII+authId;

        if(bankAccountId!= null && bankAccountId!=""){
            checkCbpiiUrl = checkCbpiiUrl+"?bankAccountId="+bankAccountId
        }

        if(checkCbpiiUrl.includes("?") && tokenUserId!= null && tokenUserId!=""){
            checkCbpiiUrl = checkCbpiiUrl+"&tokenUserId="+tokenUserId
        }else if(tokenUserId!= null && tokenUserId!=""){
            checkCbpiiUrl = checkCbpiiUrl+"?tokenUserId="+tokenUserId
        }

        if(checkCbpiiUrl.includes("?") && tppName!= null && tppName!=""){
            checkCbpiiUrl = checkCbpiiUrl+"&tppName="+tppName
        }else if(tppName!= null && tppName!=""){
            checkCbpiiUrl = checkCbpiiUrl+"?tppName="+tppName
        }
        defaultLogger.debug("["+params.userid+"]-["+params.requestid+"]-Request: "+checkCbpiiUrl);
        try{
            let data = await axiosClient.post(checkCbpiiUrl, {
            headers: {
                'Content-Type': 'application/json'
            }}, {}, {timeout : ESB_TIMEOUT_PERIOD,httpsAgent:new https.Agent({ rejectUnauthorized: false})});

            data = data.data;
            defaultLogger.debug("["+params.userid+"]-["+params.requestid+"]-Response: "+JSON.stringify(data,null,2));
            defaultLogger.info("["+params.userid+"]-["+params.requestid+"]-Exiting from cbpiiCheck()");
            return data;
        }
        catch(err){
            errorLogger.info("["+params.userid+"]-["+params.requestid+"]-Error occured in service ("+checkCbpiiUrl+"): ");
            if(err.response == null || err.response.status == null || err.response.data == null) {
				let msg = "Backend Error - " + err;
				let error = {};
				let response = {};
				response.data 	= 'An unexpected error has occured.';
				response.status 	= 500;								
				error["response"] = response;
				error.message = msg;
				errorLogger.error("["+params.userid+"]-["+params.requestid+"]-"+JSON.stringify(error,null,2));
				throw error;
            }else{
                errorLogger.error("["+params.userid+"]-["+params.requestid+"]-"+JSON.stringify(err,null,2));
                throw err;
            }
        }
    }

    /**
     * saveAuthorisedPayment service is reponsible for saving the payment details such as
     * payee account, payer account, refId, initiatorId etc.
     * 
     * @param {*} authId - authId gets generated on successfull authentication.
     * @param {*} body - body will contains payment details which will pass as json object in POST call.
     */
    async saveAuthorisedPayment(authId,body,params) {
        defaultLogger.info("["+params.userid+"]-["+params.requestid+"]-Entering into saveAuthorisedPayment()");
        defaultLogger.debug("["+params.userid+"]-["+params.requestid+"]-Request: "+SAVE_ACCOUNT+authId);
        defaultLogger.debug("["+params.userid+"]-["+params.requestid+"]-"+JSON.stringify(body,null,2));  
        try{ 
            let data = await axiosClient.post(SAVE_ACCOUNT+authId, body, {timeout : ESB_TIMEOUT_PERIOD,httpsAgent:new https.Agent({ rejectUnauthorized: false})})
            data =data.data;
            defaultLogger.debug("["+params.userid+"]-["+params.requestid+"]-Response: "+JSON.stringify(data,null,2));
            defaultLogger.info("["+params.userid+"]-["+params.requestid+"]-Exiting from saveAuthorisedPayment()");
            return data;
        }
        catch(err) {
            errorLogger.info("["+params.userid+"]-["+params.requestid+"]-Error occured in service ("+SAVE_ACCOUNT+authId+"): ");
            if(err.response == null || err.response.status == null || err.response.data == null) {
				let msg = "Backend Error - " + err;
				let error = {};
				let response = {};
				response.data 	= 'An unexpected error has occured.';
				response.status 	= 500;								
				error["response"] = response;
				error.message = msg;
				errorLogger.error("["+params.userid+"]-["+params.requestid+"]-"+JSON.stringify(error,null,2));
				throw error;
            }else{
                errorLogger.error("["+params.userid+"]-["+params.requestid+"]-"+JSON.stringify(err,null,2));
                throw err;
            }
        }
    }
}

module.exports = PaymentService;
