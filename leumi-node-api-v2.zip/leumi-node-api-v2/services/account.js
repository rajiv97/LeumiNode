const axiosClient = require('../lib/axios');
const https = require('https');
const { ESB_BASE_URL,ESB_TIMEOUT_PERIOD } = require('../config/config');
const ACCOUNT_LIST_URL = ESB_BASE_URL+"/account/list";
const ACCOUNT_SAVE_LIST = ESB_BASE_URL+"/consent/saveAccountList";
const { defaultLogger, errorLogger } = require('../lib/logging');



class AccountService {

    /**
     * getListByAuthId service is responsible for fetching list of corporate accounts using authId.
     * 
     * Get Account list for a corporate accounts.
     * 
     * @param id - authId gets generated on successfull authentication (required).
     * @param accountType - chaps,bacs,swift (optional).
     * @param currencyCode - GBP (optional).
     *  
     */
    async getListByAuthId(id,accountType,currencyCode,params) {
        defaultLogger.info("["+params.userid+"]-["+params.requestid+"]-Entering into getListByAuthId("+id+") has been called.");
        var url = ACCOUNT_LIST_URL+'/'+id
        
        if(accountType!=null && accountType!=""){
            url=url+"?accountType="+accountType;
        }

        if(url.includes("?") && currencyCode!=null && currencyCode!=""){
            url=url+"&currencyCode="+currencyCode;
        }else if(currencyCode!=null && currencyCode!=""){
            url=url+"?currencyCode="+currencyCode;
        }

        defaultLogger.debug("["+params.userid+"]-["+params.requestid+"]-Request: "+url);
        try {
            let data = await axiosClient.get(url, {timeout : ESB_TIMEOUT_PERIOD,httpsAgent:new https.Agent({ rejectUnauthorized: false})});
            data = data.data;
            defaultLogger.debug("["+params.userid+"]-["+params.requestid+"]-Response: "+JSON.stringify(data,null,2));
            defaultLogger.info("["+params.userid+"]-["+params.requestid+"]-Exiting from getListByAuthId("+id+") has been called.");
            return data;
        }
        catch(err) {
            errorLogger.info("["+params.userid+"]-["+params.requestid+"]-Error occured in service ("+url+") "+err);
            if(err.response == null || err.response.status == null || err.response.data == null) {
                let msg = "Backend Error - " + err;
                let error = {};
                let response = {};
                response.data 	= 'An unexpected error has occured.';
                response.status 	= 500;								
                error["response"] = response;
                error.message = msg;
                errorLogger.error("["+params.userid+"]-["+params.requestid+"]-"+JSON.stringify(error,null,2));
                throw error;
            }else{
                errorLogger.error("["+params.userid+"]-["+params.requestid+"]-"+JSON.stringify(err,null,2));
                throw err;
            }
        }
    }

    /**
     * saveAccountList service is responsible for saving selected accounts for which user gave its consent.
     * 
     * @param {*} authId - authId gets generated on successfull authentication.
     * @param {*} body - body will contains account details which will pass as json object in POST call.
     */
    async saveAccountList(authId,body,params) {
        defaultLogger.info("["+params.userid+"]-["+params.requestid+"]-Entering into saveAccountList() has been called.");
        defaultLogger.debug("["+params.userid+"]-["+params.requestid+"]-Request:"+ ACCOUNT_SAVE_LIST+"/"+authId);
        defaultLogger.debug("["+params.userid+"]-["+params.requestid+"]-"+JSON.stringify(body,null,2));
        try {
            let data = await axiosClient.post(ACCOUNT_SAVE_LIST+"/"+authId, body, {timeout : ESB_TIMEOUT_PERIOD,httpsAgent:new https.Agent({ rejectUnauthorized: false})});
            data = data.data;
            defaultLogger.debug("["+params.userid+"]-["+params.requestid+"]-Response: "+JSON.stringify(data,null,2));
            defaultLogger.info("["+params.userid+"]-["+params.requestid+"]-Exiting from saveAccountList() has been called.");
            return data;

        }
        catch(err) {
            errorLogger.info("["+params.userid+"]-["+params.requestid+"]-Error occured in service ("+ACCOUNT_SAVE_LIST+"/"+authId+") ");
            if(err.response == null || err.response.status == null || err.response.data == null) {
				let msg = "Backend Error - " + err;
				let error = {};
				let response = {};
				response.data 	= 'An unexpected error has occured.';
				response.status 	= 500;								
				error["response"] = response;
				error.message = msg;
				errorLogger.error("["+params.userid+"]-["+params.requestid+"]-"+JSON.stringify(error,null,2));
				throw error;
            }else{
                errorLogger.error("["+params.userid+"]-["+params.requestid+"]-"+JSON.stringify(err,null,2));
                throw err;
            }
        };
    }
}

module.exports = AccountService;