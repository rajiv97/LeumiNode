const express = require('express');
const router = express.Router();
const { defaultLogger, errorLogger} = require('../lib/logging');
const TokenService = require('../services/token');
var verifyToken = require('../lib/util');
const tokenService = new TokenService();

/**
 * This route is to call getConstents service for fetching ConsentRequest object
 * to further extract details like tppCallbackUrl, tppName and requestType etc based on requestId.
 * 
 * @param requestId - recieved from TPP. 
 */

router.get('/banks/consent-requests/:requestId',async (req, res)=>{
    const requestId = req.params.requestId;
	var userid = 'UnAuthorized', reqid = requestId;
    defaultLogger.info("["+userid+"]-["+reqid+"]-Entering route /banks/consent-requests/"+req.params.requestId);
    var params = {};
	params.userid = userid;
	params.requestid = reqid;
    try {
        const data = await tokenService.getConsent(requestId,params);
        defaultLogger.info("["+userid+"]-["+reqid+"]-Exiting from route /banks/consent-requests/"+requestId);
        res.send(data);
    } catch (err) {
        errorLogger.info("["+userid+"]-["+reqid+"]-Error occured in router (/banks/consent-requests/"+requestId+"): ");
        errorLogger.error("["+userid+"]-["+reqid+"]-"+JSON.stringify(err,null,2));
        if(err.message.indexOf('timeout') > -1){
            res.status(500).send(err.message);
        }else{
            res.status(err.response.status).send(err.response.data);
        }
    }
})


/**
 * This route is to call postUsers Service if tokenUserId is missing in the response of
 * authentication service call. 
 * 
 */
router.post('/banks/users', verifyToken.verifyToken,async (req, res) => {
    var userid = req.headers.userid, reqid = req.headers.requestid;
    defaultLogger.info("["+userid+"]-["+reqid+"]-Entering route /banks/users");
    var params = req.headers;
    const body = req.body;
    try {
        const data = await tokenService.postUsers(body,params);
        defaultLogger.info("["+userid+"]-["+reqid+"]-Exiting route /banks/users");
        res.send(data);
    } catch(err) {
        errorLogger.info("["+userid+"]-["+reqid+"]-Error occured in router (/banks/users): ");
        errorLogger.error("["+userid+"]-["+reqid+"]-"+JSON.stringify(err,null,2));
        if(err.message.indexOf('timeout') > -1){
            res.status(500).send(err.message);
        }else{
            res.status(err.response.status).send(err.response.data);
        }
    }
})

/**
 * This route is to call postConsents Service to create a consent at Token.
 * 
 */
router.post('/banks/consents', verifyToken.verifyToken,async (req, res) => {
    var userid = req.headers.userid, reqid = req.headers.requestid;
    defaultLogger.info("["+userid+"]-["+reqid+"]-Entering route /banks/consents");
    var params = req.headers;
    const body = req.body;
    try {
        const data = await tokenService.postConsents(body,params);
        defaultLogger.info("["+userid+"]-["+reqid+"]-Exiting route /banks/consents");
        res.send(data);
    } catch(err) {
        errorLogger.info("["+userid+"]-["+reqid+"]-Error occured in router (/banks/consents): ");
        errorLogger.error("["+userid+"]-["+reqid+"]-"+JSON.stringify(err,null,2));
        if(err.message.indexOf('timeout') > -1){
            res.status(500).send(err.message);
        }else{
            res.status(err.response.status).send(err.response.data);
        }
    }
})

module.exports = router;
