const express = require('express');
const router = express.Router();
const { defaultLogger, errorLogger } = require('../lib/logging');
const PaymentService = require('../services/payment');
var verifyToken = require('../lib/util');
const paymentService = new PaymentService();

/**
 * This route is to call service to cross-check, whether the account really belongs to
 * authenticated user or not for confirmation of funds based on authId.
 * 
 * @param authId - authId gets generated on successfull authentication.
 */
router.post('/cbpii/cbpiiCheck/:authId', verifyToken.verifyToken,async (req, res) => {
    var userid = req.headers.userid, reqid = req.headers.requestid;
    defaultLogger.info("["+userid+"]-["+reqid+"]-Entering into Payment: /cbpii/cbpiiCheck/"+ req.param('authId'));
    var params = req.headers;
    const authId = req.param('authId');
    const bankAccountId = req.query.bankAccountId;
    const tokenUserId = req.query.tokenUserId;
    const tppName = req.query.tppName;
    
    try{
        const data = await paymentService.cbpiiCheck(authId,bankAccountId,tokenUserId,tppName,params);
        if(data.responseCode != 0){
            defaultLogger.info("["+userid+"]-["+reqid+"]-Exiting from Payment: /cbpii/cbpiiCheck/ with responseCode: "+data.responseCode);
            res.status(400).send(data);
        }else{
            defaultLogger.info("["+userid+"]-["+reqid+"]-Exiting from Payment: /cbpii/cbpiiCheck/ with responseCode: "+data.responseCode);
            res.status(200).send(data);
        }
        
    }
    catch(err) {
        errorLogger.info("["+userid+"]-["+reqid+"]-Error occured in router (/cbpii/cbpiiCheck/"+authId+"):");
        errorLogger.error("["+userid+"]-["+reqid+"]-"+JSON.stringify(err,null,2));
        if (err.message!=null && err.message.indexOf('timeout') > -1) {
            res.status(500).send(err.message);
        } else if(err.response !=null && err.response.status != null && err.response.data != null){
            errorLogger.info("["+userid+"]-["+reqid+"]- Error Response from ESB:" +JSON.stringify(err.response.data, null, 2));
            res.status(err.response.status).send(err.response.data);
        } else {
            errorLogger.info("["+userid+"]-["+reqid+"]- Unexpected Error Occured" );
            res.status(500).send("Unexpected Error Occured");
        }
    }
});

/**
 * This route is to call saveAuthorisedPayment service to save the payment details such as
 * payee account, payer account, refId, initiatorId etc. 
 * 
 * @param authId - authId gets generated on successfull authentication.
 */
router.post('/saveAuthorisedPayment/:authId', verifyToken.verifyToken,async (req, res, next) => {
    var userid = req.headers.userid, reqid = req.headers.requestid;
    defaultLogger.info("["+userid+"]-["+reqid+"]-Entering into Payment: /saveAuthorisedPayment/"+ req.param('authId'));
    var params = req.headers;
    const authId = req.param('authId');
    const body = req.body;
    try {
        const data = await paymentService.saveAuthorisedPayment(authId,body,params);
        //send data with appropriate http status code based on responseCode recieved.
        if(data[0].responseCode == 0 || data[0].responseCode == 1){
            defaultLogger.info("["+userid+"]-["+reqid+"]-Exiting from Payment: /saveAuthorisedPayment with responseCode: "+data[0].responseCode);
            res.status(200).send(data);
        }else{
            defaultLogger.info("["+userid+"]-["+reqid+"]-Exiting from Payment: /saveAuthorisedPayment with responseCode: "+data[0].responseCode);
            res.status(400).send(data);
        }
    }
    catch(err) {
        errorLogger.info("["+userid+"]-["+reqid+"]-Error occured in router (/saveAuthorisedPayment/"+authId+"):");
        errorLogger.error("["+userid+"]-["+reqid+"]-"+JSON.stringify(err,null,2));
        if (err.message!=null && err.message.indexOf('timeout') > -1) {
            res.status(500).send(err.message);
        } else if(err.response !=null && err.response.status != null && err.response.data != null){
            errorLogger.info("["+userid+"]-["+reqid+"]- Error Response from ESB:" +JSON.stringify(err.response.data, null, 2));
            res.status(err.response.status).send(err.response.data);
        } else {
            errorLogger.info("["+userid+"]-["+reqid+"]- Unexpected Error Occured" );
            res.status(500).send("Unexpected Error Occured");
        }
    }
})

module.exports = router;
