const env = process.env.NODE_ENV || 'dev';
process.env.NODE_ENV = env;
console.log('env === ', process.env.NODE_ENV);
//Decides which profiles needs to be pick for configurations based on env.
module.exports = require(`./.${env}.js`);
